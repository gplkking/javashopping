package view;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import dao.ProductDAO;
import dao.OrderDAO;
import model.Product;
import model.Order;
import util.Session;

import java.awt.*;
import java.util.List;

public class MainFrame extends JFrame {
    private ProductDAO productDAO = new ProductDAO();
    private OrderDAO orderDAO = new OrderDAO();
    private DefaultTableModel model;
    private JTable table;
    private JTextField tfSearch;
    private String currentUserName;
    private boolean isLoggedIn;

    public MainFrame() {
        this(Session.getCurrentUser() != null ? Session.getCurrentUser().getName() : "비로그인 사용자");
    }

    public MainFrame(String username) {
        this.currentUserName = username;
        this.isLoggedIn = Session.getCurrentUser() != null;

        setTitle("메인 화면");
        setSize(900, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        Font font = new Font("맑은 고딕", Font.PLAIN, 14);

        // 상단 패널 설정
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        topPanel.setBackground(new Color(245, 245, 255));

        JLabel lblUser = new JLabel(isLoggedIn ? "사용자: " + currentUserName : "비로그인 사용자");
        tfSearch = new JTextField(15);

        JButton btnSearch = new JButton("검색");
        JButton btnAddToCart = new JButton("장바구니에 추가");
        JButton btnCart = new JButton("장바구니 보기");
        JButton btnOrders = new JButton("주문 내역");
        JButton btnBack = new JButton(isLoggedIn ? "로그아웃" : "돌아가기");

        JButton[] buttons = {btnSearch, btnAddToCart, btnCart, btnOrders, btnBack};
        for (JButton btn : buttons) btn.setFont(font);

        topPanel.add(lblUser);
        topPanel.add(tfSearch);
        for (JButton btn : buttons) topPanel.add(btn);
        add(topPanel, BorderLayout.NORTH);

        // 테이블 설정
        model = new DefaultTableModel(new Object[]{"ID", "상품명", "가격", "재고"}, 0) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(model);
        table.setFont(font);
        table.setRowHeight(25);
        table.getTableHeader().setFont(font);
        table.getTableHeader().setReorderingAllowed(false);

        // 중앙 정렬
        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(JLabel.CENTER);
        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(center);
        }

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // 버튼 동작
        btnSearch.addActionListener(e -> loadProducts(tfSearch.getText()));

        btnAddToCart.addActionListener(e -> {
            if (!isLoggedIn) {
                JOptionPane.showMessageDialog(this, "로그인이 필요합니다.");
                return;
            }
            addToCart();
        });

        btnCart.addActionListener(e -> {
            if (!isLoggedIn) {
                JOptionPane.showMessageDialog(this, "로그인이 필요합니다.");
                return;
            }
            new CartFrame();
        });

        btnOrders.addActionListener(e -> {
            if (!isLoggedIn) {
                JOptionPane.showMessageDialog(this, "로그인이 필요합니다.");
                return;
            }
            new OrderFrame();
        });

        btnBack.addActionListener(e -> {
            Session.setCurrentUser(null);  // 로그아웃 처리
            dispose();
            new HomeFrame();
        });

        loadProducts(null);
        setVisible(true);
    }

    private void loadProducts(String keyword) {
        model.setRowCount(0);
        List<Product> list = productDAO.getAllProducts();
        for (Product p : list) {
            if (keyword == null || p.getName().contains(keyword)) {
                model.addRow(new Object[]{p.getId(), p.getName(), p.getPrice(), p.getStock()});
            }
        }
    }

    private void addToCart() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "상품을 선택하세요.");
            return;
        }

        int id = (int) model.getValueAt(row, 0);
        String name = (String) model.getValueAt(row, 1);
        int price = (int) model.getValueAt(row, 2);

        String input = JOptionPane.showInputDialog("수량을 입력하세요:");
        if (input == null || input.trim().isEmpty()) return;

        try {
            int quantity = Integer.parseInt(input);
            if (quantity <= 0) throw new NumberFormatException();

            int userId = Session.getCurrentUser().getId();

            // 같은 상품이 이미 장바구니에 있는지 확인
            Order existingOrder = orderDAO.getOrdersByUser(userId).stream()
                .filter(ord -> ord.getProductId() == id && "CART".equals(ord.getStatus()))
                .findFirst()
                .orElse(null);

            if (existingOrder != null) {
                int newQty = existingOrder.getQuantity() + quantity;
                boolean updated = orderDAO.updateOrderQuantity(existingOrder.getId(), newQty);

                if (updated) {
                    int option = JOptionPane.showOptionDialog(
                        this,
                        "장바구니에 이미 있는 상품입니다.\n수량이 추가되었습니다!\n장바구니로 이동하시겠습니까?",
                        "알림",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.INFORMATION_MESSAGE,
                        null,
                        new String[]{"장바구니로 이동", "계속 쇼핑하기"},
                        "장바구니로 이동"
                    );
                    if (option == JOptionPane.YES_OPTION) {
                        new CartFrame();
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "수량 업데이트 실패");
                }
            } else {
                Order newOrder = new Order(0, userId, id, quantity, price * quantity, null, "CART");
                if (orderDAO.addOrder(newOrder)) {
                    int option = JOptionPane.showOptionDialog(
                        this,
                        "장바구니에 추가되었습니다!\n장바구니로 이동하시겠습니까?",
                        "알림",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.INFORMATION_MESSAGE,
                        null,
                        new String[]{"장바구니로 이동", "계속 쇼핑하기"},
                        "장바구니로 이동"
                    );
                    if (option == JOptionPane.YES_OPTION) {
                        new CartFrame();
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "장바구니 추가 실패");
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "올바른 수량을 입력하세요.");
        }
    }
}
