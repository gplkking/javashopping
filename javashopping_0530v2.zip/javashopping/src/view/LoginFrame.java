package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import dao.UserDAO;
import model.User;
import util.Session;

public class LoginFrame extends JFrame {
    private UserDAO userDAO = new UserDAO();
    private JTextField tfUsername;
    private JPasswordField pfPassword;

    public LoginFrame() {
        setTitle("로그인");
        setSize(380, 220);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        //메인 패널
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        panel.setBackground(new Color(245, 245, 255));
        GridBagConstraints gbc = new GridBagConstraints();
        Font font = new Font("맑은 고딕", Font.PLAIN, 14);

        tfUsername = new JTextField(15);
        pfPassword = new JPasswordField(15);
        tfUsername.setFont(font);
        pfPassword.setFont(font);

        //아이디 라벨
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.EAST;
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("아이디:"), gbc);

        //아이디 입력창
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(tfUsername, gbc);

        //비밀번호 라벨
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel("비밀번호:"), gbc);

        //비밀번호 입력창
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(pfPassword, gbc);

        //버튼 패널
        JButton btnLogin = new JButton("로그인");
        JButton btnCancel = new JButton("취소");
        btnLogin.setFont(font);
        btnCancel.setFont(font);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnPanel.setBackground(new Color(245, 245, 255));
        btnPanel.add(btnLogin);
        btnPanel.add(btnCancel);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.EAST;
        panel.add(btnPanel, gbc);

        add(panel);

        //공통 로그인 처리
        ActionListener loginAction = e -> {
            String username = tfUsername.getText();
            String password = new String(pfPassword.getPassword());

            User user = userDAO.login(username, password);
            if (user != null) {
                Session.setCurrentUser(user);
                JOptionPane.showMessageDialog(this, "로그인 성공!");

                if ("ADMIN".equalsIgnoreCase(user.getRole())) {
                    new AdminFrame();
                } else {
                    new MainFrame();
                }

                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "아이디 또는 비밀번호를 확인하세요.");
            }
        };

        btnLogin.addActionListener(loginAction);
        pfPassword.addActionListener(loginAction);

        btnCancel.addActionListener(e -> {
            dispose();
            new HomeFrame();
        });

        setVisible(true);
    }
}
