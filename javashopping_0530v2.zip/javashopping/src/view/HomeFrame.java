package view;

import javax.swing.*;
import java.awt.*;

public class HomeFrame extends JFrame {

    public HomeFrame() {
        setTitle("홈 화면");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        //메인 패널 (전체 영역)
        JPanel panel = new JPanel();
        panel.setBackground(new Color(240, 240, 255));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30)); // 여백

        //제목 라벨
        JLabel titleLabel = new JLabel("자바 쇼핑몰");
        titleLabel.setFont(new Font("맑은 고딕", Font.BOLD, 20));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(titleLabel);

        panel.add(Box.createRigidArea(new Dimension(0, 20))); // 여백

        //버튼들
        JButton btnLogin = new JButton("로그인");
        JButton btnRegister = new JButton("회원가입");
        JButton btnProductList = new JButton("상품목록");

        Font btnFont = new Font("맑은 고딕", Font.PLAIN, 14);
        for (JButton btn : new JButton[]{btnLogin, btnRegister, btnProductList}) {
            btn.setFont(btnFont);
            btn.setAlignmentX(Component.CENTER_ALIGNMENT);
            btn.setMaximumSize(new Dimension(200, 40));
            btn.setBackground(Color.WHITE);
            btn.setFocusPainted(false);
            panel.add(btn);
            panel.add(Box.createRigidArea(new Dimension(0, 10))); // 버튼 간격
        }

        //이벤트
        btnLogin.addActionListener(e -> {
            new LoginFrame();
            dispose();
        });

        btnRegister.addActionListener(e -> {
            new RegisterFrame();
            dispose();
        });

        btnProductList.addActionListener(e -> {
            new MainFrame();
            dispose();
        });

        add(panel);
        setVisible(true);
    }
}
