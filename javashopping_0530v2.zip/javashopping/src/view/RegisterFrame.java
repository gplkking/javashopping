package view;

import javax.swing.*;
import dao.UserDAO;
import model.User;

import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class RegisterFrame extends JFrame {
	private UserDAO userDAO = new UserDAO();
	private JTextField tfUsername, tfName;
	private JPasswordField pfPassword;

	public RegisterFrame() {
		setTitle("회원가입");
		setSize(400, 250);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);

		Font font = new Font("맑은 고딕", Font.PLAIN, 14);

		JPanel panel = new JPanel(new GridBagLayout());
		panel.setBackground(new Color(245, 245, 255));
		panel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(10, 10, 10, 10);

		// 아이디
		JLabel lblUsername = new JLabel("아이디:");
		lblUsername.setFont(font);
		tfUsername = new JTextField(20);
		tfUsername.setFont(font);

		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.anchor = GridBagConstraints.EAST;
		panel.add(lblUsername, gbc);

		gbc.gridx = 1;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.weightx = 1.0;
		panel.add(tfUsername, gbc);

		// 비밀번호
		JLabel lblPassword = new JLabel("비밀번호:");
		lblPassword.setFont(font);
		pfPassword = new JPasswordField(20);
		pfPassword.setFont(font);

		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.anchor = GridBagConstraints.EAST;
		gbc.fill = GridBagConstraints.NONE;
		gbc.weightx = 0;
		panel.add(lblPassword, gbc);

		gbc.gridx = 1;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.weightx = 1.0;
		panel.add(pfPassword, gbc);

		// 이름
		JLabel lblName = new JLabel("이름:");
		lblName.setFont(font);
		tfName = new JTextField(20);
		tfName.setFont(font);

		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.anchor = GridBagConstraints.EAST;
		gbc.fill = GridBagConstraints.NONE;
		gbc.weightx = 0;
		panel.add(lblName, gbc);

		gbc.gridx = 1;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.weightx = 1.0;
		panel.add(tfName, gbc);

		// 버튼
		JButton btnRegister = new JButton("가입");
		JButton btnCancel = new JButton("취소");
		btnRegister.setFont(font);
		btnCancel.setFont(font);

		JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		btnPanel.setBackground(new Color(245, 245, 255));
		btnPanel.add(btnRegister);
		btnPanel.add(btnCancel);

		gbc.gridx = 0;
		gbc.gridy = 3;
		gbc.gridwidth = 2;
		gbc.anchor = GridBagConstraints.EAST;
		gbc.fill = GridBagConstraints.NONE;
		panel.add(btnPanel, gbc);

		// 이벤트
		btnRegister.addActionListener(e -> register());
		btnCancel.addActionListener(e -> {
			new HomeFrame();
			dispose();
		});

		tfName.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					register();
				}
			}
		});

		add(panel);
		setVisible(true);
	}

	private void register() {
	    String username = tfUsername.getText().trim();
	    String password = new String(pfPassword.getPassword());
	    String name = tfName.getText().trim();
	    
	    //아이디 검열
	    String[] blockedIds = {"admin", "root", "system"};
	    for (String blocked : blockedIds) {
	        if (blocked.equalsIgnoreCase(username)) {
	            JOptionPane.showMessageDialog(this, blocked + "은 사용할 수 없는 아이디입니다.");
	            return;
	        }
	    }

	    if (userDAO.register(new User(0, username, password, name, "USER"))) {
	        JOptionPane.showMessageDialog(this, "가입 성공!");
	        dispose();
	        new LoginFrame(); //자동으로 로그인 화면으로
	    } else {
	        JOptionPane.showMessageDialog(this, "가입 실패!");
	    }
	}
}
